const _0x4465aa = _0x2070;
(function (_0x201717, _0x1ae5ea) {
    const _0x4dad0f = _0x2070,
        _0x51ebd6 = _0x201717();
    while (!![]) {
        try {
            const _0x2a25e1 =
                -parseInt(_0x4dad0f(0xc3)) / 0x1 * (parseInt(_0x4dad0f(0xc1)) / 0x2) +
                -parseInt(_0x4dad0f(0xbc)) / 0x3 +
                parseInt(_0x4dad0f(0xca)) / 0x4 * (-parseInt(_0x4dad0f(0xc7)) / 0x5) +
                -parseInt(_0x4dad0f(0xcb)) / 0x6 * (parseInt(_0x4dad0f(0xba)) / 0x7) +
                -parseInt(_0x4dad0f(0xc2)) / 0x8 * (-parseInt(_0x4dad0f(0xcf)) / 0x9) +
                -parseInt(_0x4dad0f(0xbd)) / 0xa +
                -parseInt(_0x4dad0f(0xb7)) / 0xb * (-parseInt(_0x4dad0f(0xb4)) / 0xc);
            if (_0x2a25e1 === _0x1ae5ea) break;
            else _0x51ebd6["push"](_0x51ebd6["shift"]());
        } catch (_0x5b55e6) {
            _0x51ebd6["push"](_0x51ebd6["shift"]());
        }
    }
})(_0x1ebd, 0xf3d2a);

import { performance } from "perf_hooks";

let handler = async (_0x255d92, { conn: _0x450425, text: _0x22a382 }) => {
    const _0x5187c9 = _0x2070;

    // Messaggi personalizzati da Youns 🥵
    let _0x8096ad = `🤟🏻 Ora faccio un ditalino a *${_0x22a382}*...`,
        _0x3b7df4 = `👆🏻 Preparati!`,
        _0x3a12c3 = `✌🏻 Andiamo avanti...`,
        _0x2bd5b3 = `☝🏻 Quasi fatto...`,
        _0x8ea5f1 = `✌🏻 È il momento giusto!`,
        _0x4abd8e = `👋🏻 Fatto?`,
        _0x2c1ab2 = `👋🏻 Un attimo ancora...`,
        _0x18ce95 = `✌🏻 Wow, sembra promettere bene!`,
        _0x3b8ad1 = `🤟🏻 Ora ci siamo...`,
        _0x210b47 = `☝🏻 Non ci credo!`,
        _0x1f6f99 = `🤟🏻 Epico!`,
        _0x5d3e2b = `👋🏻 Ohhssy, ancora, ahhhh!`;

    // Sequenza dei messaggi 🤓
    await _0x255d92[_0x5187c9(0xb9)](_0x8096ad);
    await _0x255d92[_0x5187c9(0xb9)](_0x3b7df4);
    await _0x255d92[_0x5187c9(0xb9)](_0x3a12c3);
    await _0x255d92[_0x5187c9(0xb9)](_0x2bd5b3);
    await _0x255d92["reply"](_0x8ea5f1);
    await _0x255d92[_0x5187c9(0xb9)](_0x4abd8e);
    await _0x255d92["reply"](_0x2c1ab2);
    await _0x255d92[_0x5187c9(0xb9)](_0x18ce95);
    await _0x255d92[_0x5187c9(0xb9)](_0x3b8ad1);
    await _0x255d92[_0x5187c9(0xb9)](_0x210b47);
    await _0x255d92[_0x5187c9(0xb9)](_0x1f6f99);
    await _0x255d92[_0x5187c9(0xb9)](_0x5d3e2b);

    // Calcolo del tempo (per Youns non esiste, lui è immortale)
    let _0x48909b = performance[_0x5187c9(0xb6)](),
        _0x5c4ca0 = performance[_0x5187c9(0xb6)](),
        _0x281d6a = "" + (_0x5c4ca0 - _0x48909b),
        _0x2e5864 = `✨ ${_0x22a382} è venuta!🥵 Dopo *${_0x281d6a}ms*!`;

    _0x450425[_0x5187c9(0xb9)](_0x255d92["chat"], _0x2e5864, _0x255d92);
};

handler[_0x4465aa(0xc4)] = [_0x4465aa(0xc6)];
handler[_0x4465aa(0xd2)] = [_0x4465aa(0xce)];
export default handler;

function pickRandom(_0x4dd2b0) {
    const _0xbaffd5 = _0x4465aa;
    return _0x4dd2b0[Math[_0xbaffd5(0xbb)](Math[_0xbaffd5(0xcd)]() * _0x4dd2b0["length"])];
}

function _0x2070(_0xb5f9f, _0x476994) {
    const _0x1ebdef = _0x1ebd();
    return (
        (_0x2070 = function (_0x207090, _0x50d552) {
            _0x207090 = _0x207090 - 0xb4;
            let _0x2ba6f4 = _0x1ebdef[_0x207090];
            return _0x2ba6f4;
        }),
        _0x2070(_0xb5f9f, _0x476994)
    );
}

function _0x1ebd() {
    const _0x41ff98 = [
        "5082pvnnNJ",
        "✌🏻\x0aㅤ",
        "random",
        "ditalino",
        "5436RawcFQ",
        "ㅤ\x0a☝🏻",
        "Ora\x20faccio\x20un\x20ditalino\x20a\x20",
        "command",
        "276ePSOzK",
        "☝🏻\x0aㅤ",
        "now",
        "1392941pmxTvN",
        "🤟🏻\x0aㅤ",
        "reply",
        "2079uKmCTk",
        "floor",
        "1668675zACbLP",
        "1707320ywCMAi",
        "Oh\x20",
        "ㅤ\x0a✌🏻",
        "ㅤ\x0a👆🏻",
        "91730fZBBro",
        "5936lADwkq",
        "27VnSLZz",
        "tags",
        "ㅤ\x0a🤟🏻",
        "fun",
        "90695LKgiuM",
        "👋🏻\x0aㅤ",
        "ㅤ\x0a👋🏻",
        "32TTYBIU",
    ];
    _0x1ebd = function () {
        return _0x41ff98;
    };
    return _0x1ebd();
}
