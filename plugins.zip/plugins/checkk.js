function _0x130e() {
    const _0x10b98a = [
        'split',
        'fail',
        '🛠️\x20@',
        '🤖\x20Messaggio\x20da\x20bot',
        '💻\x20WhatsApp\x20Web\x20o\x20bot',
        '╭─[\x20📍\x20*Analisi\x20Utente*\x20]\x0a│\x20👤\x20Utente:\x20*@',
        'includes',
        'tvVYo',
        'oCQvT',
        'giCSZ',
        '⚠️\x20Impossibile\x20rilevare\x20il\x20dispositivo',
        '💻\x20WhatsApp\x20Web',
        '33291WLEsmf',
        'Hajdr',
        '13156660OHaeNw',
        '3525666HmYmdy',
        'key',
        'DDjWW',
        '2390pAHSVk',
        'false_',
        'groupParticipantsUpdate',
        'LIuKo',
        'BDfpM',
        '❗Rispondi\x20a\x20un\x20messaggio\x20per\x20analizzare\x20il\x20dispositivo\x20usato',
        'MTnda',
        'sendMessage',
        'hVeOe',
        'checkb',
        '4wdRWaQ',
        'LFiwX',
        'AroLP',
        'NmaZo',
        'IPOgS',
        'RbKPv',
        'rPyyo',
        'cWjxI',
        'VcNsQ',
        '51790PJWFWX',
        'Errore\x20nel\x20leggere\x20id:',
        '4796912CGXyOc',
        'pOzfC',
        'demote',
        'jCMMI',
        'command',
        'promote',
        'sconosciuto',
        'OwOHD',
        'id\x20del\x20messaggio\x20non\x20riconosciuto',
        'Vpnna',
        'UiHBF',
        'reply',
        'log',
        'iTIuI',
        'Errore\x20nel\x20togliere\x20admin\x20da\x20se\x20stesso',
        'tPiBA',
        'TmSMg',
        'wdvGU',
        '📱\x20Android',
        'TJyfF',
        'quoted',
        'mQZyH',
        '[ANALISI]\x20Nuovo\x20ID\x20non\x20riconosciuto:',
        'IFpxH',
        'Dispositivo\x20sconosciuto\x20🕵️‍♂️',
        'ysknb',
        'FwcHv',
        'startsWith',
        '🖥️\x20WhatsApp\x20Desktop',
        '\x20errore\x20nel\x20recuperare\x20id\x20del\x20messaggio.',
        '🍏\x20iOS',
        'admin',
        'true_',
        'QBlLt',
        '449594EYVPyN',
        'wZktd',
        '7pAwdQo',
        'aCmLY',
        'groupMetadata',
        '3EB0',
        'filter',
        'KUjYT',
        'lyLBY',
        'participants',
        'mUcZG',
        'replace',
        'rARXf',
        '556774PILXjp',
        'qbKHt',
        'jid',
        '3DOvtPh',
        'chat',
        'test',
        '❌\x20Il\x20bot\x20deve\x20essere\x20admin\x20per\x20eseguire\x20questa\x20azione.',
        '🤖\x20Android\x20(vecchio\x20schema)',
        'nOCKL',
        'lbyKG',
        'MjzjV',
        'eDoNo',
        'YOqUx'
    ];
    _0x130e = function () {
        return _0x10b98a;
    };
    return _0x130e();
}
const _0x5e71f9 = _0x3a97;
function _0x3a97(_0x7acb20, _0x14c561) {
    const _0x248c98 = _0x130e();
    return _0x3a97 = function (_0x24805a, _0x44ffc4) {
        _0x24805a = _0x24805a - (-0x531 + -0x1 * -0xd75 + 0x6fb * -0x1);
        let _0xa55ede = _0x248c98[_0x24805a];
        return _0xa55ede;
    }, _0x3a97(_0x7acb20, _0x14c561);
}
(function (_0x12979c, _0x283b17) {
    const _0x9816a8 = _0x3a97, _0x538704 = _0x12979c();
    while (!![]) {
        try {
            const _0x3b98fb = parseInt(_0x9816a8(0x18f)) / (-0x5 * -0x2c1 + 0x4c * -0x6d + 0x7 * 0x2a8) + -parseInt(_0x9816a8(0x19c)) / (-0x1 * -0x556 + -0x1da * -0x9 + -0x15fe) * (parseInt(_0x9816a8(0x19f)) / (0x2552 + -0x15 * -0x45 + -0x2af8)) + -parseInt(_0x9816a8(0x162)) / (0x1492 + -0x73a + -0x1 * 0xd54) * (parseInt(_0x9816a8(0x16b)) / (0x74c + 0x456 * -0x2 + 0x165)) + -parseInt(_0x9816a8(0x155)) / (-0x23 * 0x28 + -0x14 * -0x14c + 0x1472 * -0x1) * (-parseInt(_0x9816a8(0x191)) / (0x4e * -0x41 + -0x1141 + 0x2516)) + -parseInt(_0x9816a8(0x16d)) / (-0x10fc + -0x3 * 0x8c4 + 0x2b50) + -parseInt(_0x9816a8(0x152)) / (0x135a + -0x1 * 0x2383 + 0x1032) * (parseInt(_0x9816a8(0x158)) / (-0xb7b * 0x1 + 0x1e35 * -0x1 + -0xe * -0x2fb)) + parseInt(_0x9816a8(0x154)) / (0x9fb * 0x2 + -0x209 * -0x11 + -0x3684);
            if (_0x3b98fb === _0x283b17)
                break;
            else
                _0x538704['push'](_0x538704['shift']());
        } catch (_0x4abaef) {
            _0x538704['push'](_0x538704['shift']());
        }
    }
}(_0x130e, -0xc12e4 + 0x8b860 + -0x3 * -0x3763b));
let handler = async (_0x98a157, {
    conn: _0x25f16c,
    command: _0x5f95bd
}) => {
    const _0x4f5543 = _0x3a97, _0x20d197 = {
            'eDoNo': _0x4f5543(0x185),
            'MjzjV': _0x4f5543(0x183),
            'OwOHD': _0x4f5543(0x175),
            'aCmLY': _0x4f5543(0x149),
            'TmSMg': _0x4f5543(0x150),
            'rPyyo': _0x4f5543(0x18b),
            'cWjxI': _0x4f5543(0x189),
            'IPOgS': _0x4f5543(0x17b),
            'FyMym': _0x4f5543(0x1a3),
            'FwcHv': _0x4f5543(0x17f),
            'jCMMI': _0x4f5543(0x151),
            'NmaZo': function (_0x3f2aa7, _0x9e435c) {
                return _0x3f2aa7 === _0x9e435c;
            },
            'qbKHt': _0x4f5543(0x161),
            'AroLP': function (_0x430038, _0x3671ff) {
                return _0x430038 === _0x3671ff;
            },
            'Vpnna': _0x4f5543(0x16c),
            'IDFsi': _0x4f5543(0x15b),
            'KUjYT': 'ybfhq',
            'tvVYo': _0x4f5543(0x17e),
            'lbyKG': function (_0x51fd96, _0xb7f550) {
                return _0x51fd96 !== _0xb7f550;
            },
            'TJyfF': _0x4f5543(0x190),
            'iTIuI': _0x4f5543(0x18e),
            'RbKPv': _0x4f5543(0x16f),
            'rARXf': _0x4f5543(0x157),
            'YOqUx': _0x4f5543(0x15d),
            'BDfpM': _0x4f5543(0x173),
            'nOCKL': _0x4f5543(0x159),
            'tPiBA': _0x4f5543(0x18d),
            'pOzfC': 'lyLBY',
            'IFpxH': _0x4f5543(0x194),
            'hVeOe': _0x4f5543(0x182),
            'mUcZG': function (_0x592491, _0x5333c5) {
                return _0x592491 === _0x5333c5;
            },
            'idVLW': 'pFsMJ',
            'aDQEG': _0x4f5543(0x186),
            'dEUoe': function (_0x70ae65, _0x43988b) {
                return _0x70ae65 !== _0x43988b;
            },
            'LFiwX': _0x4f5543(0x153),
            'giCSZ': _0x4f5543(0x14e),
            'UiHBF': 'lJpfU'
        };
    if (_0x20d197[_0x4f5543(0x165)](_0x5f95bd, _0x20d197[_0x4f5543(0x19d)])) {
        const _0x18a658 = await _0x25f16c[_0x4f5543(0x193)](_0x98a157[_0x4f5543(0x1a0)]), _0x1da510 = _0x25f16c['user'][_0x4f5543(0x19e)], _0xfc7e47 = _0x18a658['participants']['some'](_0x515e1b => _0x515e1b['id'] === _0x1da510 && _0x515e1b[_0x4f5543(0x18c)]);
        if (!_0xfc7e47)
            return _0x98a157['reply'](_0x4f5543(0x1a2));
        const _0x1d77df = _0x98a157['sender'], _0x25aec4 = _0x18a658[_0x4f5543(0x198)];
        try {
            _0x20d197[_0x4f5543(0x164)](_0x4f5543(0x16a), _0x4f5543(0x16a)) ? await _0x25f16c[_0x4f5543(0x15a)](_0x98a157[_0x4f5543(0x1a0)], [_0x1d77df], _0x4f5543(0x172)) : (_0x398e13 = _0x20d197['eDoNo'], _0x157e26['log'](_0x20d197[_0x4f5543(0x1a6)], _0x2e18f2));
        } catch (_0x2ab017) {
            console[_0x4f5543(0x179)](_0x20d197[_0x4f5543(0x176)], _0x1d77df, _0x2ab017);
        }
        const _0x4179b3 = _0x25aec4[_0x4f5543(0x195)](_0x3777ac => _0x3777ac[_0x4f5543(0x18c)] && _0x3777ac['id'] !== _0x1da510 && _0x3777ac['id'] !== _0x1d77df);
        for (const _0x2ace1e of _0x4179b3) {
            try {
                'LIuKo' !== _0x20d197['IDFsi'] ? _0x44f5a1[_0x4f5543(0x179)](_0x20d197[_0x4f5543(0x174)], _0x41f581['id'], _0x44a35c) : await _0x25f16c['groupParticipantsUpdate'](_0x98a157[_0x4f5543(0x1a0)], [_0x2ace1e['id']], 'demote');
            } catch (_0xb2340) {
                _0x20d197[_0x4f5543(0x165)](_0x20d197[_0x4f5543(0x196)], _0x20d197[_0x4f5543(0x14d)]) ? _0x5f3fbb = _0x20d197[_0x4f5543(0x192)] : console['log'](_0x20d197[_0x4f5543(0x174)], _0x2ace1e['id'], _0xb2340);
            }
        }
        try {
            _0x20d197[_0x4f5543(0x1a5)](_0x20d197[_0x4f5543(0x180)], _0x20d197[_0x4f5543(0x17a)]) ? await _0x25f16c[_0x4f5543(0x15a)](_0x98a157[_0x4f5543(0x1a0)], [_0x1da510], _0x20d197[_0x4f5543(0x167)]) : _0x3956d3 = _0x20d197['TmSMg'];
        } catch (_0x5e8922) {
            _0x20d197[_0x4f5543(0x165)](_0x20d197[_0x4f5543(0x19b)], _0x20d197[_0x4f5543(0x19b)]) ? console[_0x4f5543(0x179)]('Errore\x20nel\x20togliere\x20admin\x20da\x20se\x20stesso', _0x5e8922) : _0x40ec96 = _0x20d197[_0x4f5543(0x168)];
        }
        return _0x98a157[_0x4f5543(0x178)](_0x4f5543(0x1ab) + _0x1d77df[_0x4f5543(0x1a9)]('@')[0x24b * -0xd + -0xc * 0xfe + 0x29b7] + _0x4f5543(0x18a), null, { 'mentions': [_0x1d77df] });
    }
    if (!_0x98a157[_0x4f5543(0x181)])
        return _0x98a157[_0x4f5543(0x178)](_0x20d197[_0x4f5543(0x1a8)]);
    const _0x1c647e = _0x98a157[_0x4f5543(0x181)]['id'] || _0x98a157[_0x4f5543(0x181)][_0x4f5543(0x156)]?.['id'], _0x4fe781 = _0x98a157[_0x4f5543(0x181)]['sender'] || _0x20d197[_0x4f5543(0x15c)], _0x236691 = _0x4fe781[_0x4f5543(0x19a)](/@.+/, '');
    let _0x993434 = _0x4f5543(0x185);
    if (!_0x1c647e)
        _0x993434 = _0x20d197[_0x4f5543(0x17d)];
    else {
        if (/^[a-zA-Z]+-[a-fA-F0-9]+$/[_0x4f5543(0x1a1)](_0x1c647e))
            _0x993434 = _0x20d197['aCmLY'];
        else {
            if (_0x1c647e[_0x4f5543(0x188)](_0x20d197[_0x4f5543(0x1a4)]) || _0x1c647e['startsWith'](_0x20d197[_0x4f5543(0x17c)]))
                _0x20d197[_0x4f5543(0x165)](_0x4f5543(0x197), _0x20d197[_0x4f5543(0x16e)]) ? _0x993434 = _0x20d197[_0x4f5543(0x170)] : _0x4c3e74 = _0x20d197['rPyyo'];
            else {
                if (_0x1c647e[_0x4f5543(0x188)](_0x20d197[_0x4f5543(0x184)]) && /^[A-Z0-9]+$/[_0x4f5543(0x1a1)](_0x1c647e))
                    _0x993434 = _0x4f5543(0x14a);
                else {
                    if (_0x1c647e[_0x4f5543(0x14c)](':'))
                        _0x993434 = _0x20d197['cWjxI'];
                    else {
                        if (/^[A-F0-9]{32}$/i[_0x4f5543(0x1a1)](_0x1c647e))
                            _0x20d197['NmaZo'](_0x20d197[_0x4f5543(0x160)], _0x20d197[_0x4f5543(0x160)]) ? _0x993434 = _0x20d197[_0x4f5543(0x187)] : _0x2e080d = _0x20d197[_0x4f5543(0x169)];
                        else {
                            if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i[_0x4f5543(0x1a1)](_0x1c647e))
                                _0x20d197[_0x4f5543(0x199)](_0x20d197['idVLW'], _0x20d197['aDQEG']) ? _0x974c11[_0x4f5543(0x179)](_0x20d197[_0x4f5543(0x166)], _0x1df707) : _0x993434 = _0x20d197[_0x4f5543(0x168)];
                            else {
                                if (/^[A-Z0-9]{20,25}$/i[_0x4f5543(0x1a1)](_0x1c647e) && !_0x1c647e['startsWith'](_0x20d197[_0x4f5543(0x184)]))
                                    _0x4f5543(0x15e) !== _0x4f5543(0x15e) ? _0x3ac33c = _0x20d197['FyMym'] : _0x993434 = '🍏\x20iOS';
                                else
                                    _0x1c647e[_0x4f5543(0x188)](_0x20d197[_0x4f5543(0x184)]) ? _0x20d197['dEUoe'](_0x20d197[_0x4f5543(0x163)], _0x20d197[_0x4f5543(0x14f)]) ? _0x993434 = '🤖\x20Android\x20(vecchio\x20schema)' : _0x5aea1f = _0x20d197['FwcHv'] : _0x20d197[_0x4f5543(0x177)] !== _0x20d197['UiHBF'] ? _0x20be53 = _0x20d197[_0x4f5543(0x170)] : (_0x993434 = _0x20d197[_0x4f5543(0x1a7)], console[_0x4f5543(0x179)](_0x20d197[_0x4f5543(0x1a6)], _0x1c647e));
                            }
                        }
                    }
                }
            }
        }
    }
    const _0x3b2e1e = _0x4f5543(0x14b) + _0x236691 + '*\x0a│\x20💽\x20Origine:\x20' + _0x993434 + '\x0a╰───────────────';
    await _0x25f16c[_0x4f5543(0x15f)](_0x98a157[_0x4f5543(0x1a0)], {
        'text': _0x3b2e1e,
        'mentions': [_0x4fe781]
    }, { 'quoted': _0x98a157 });
};
handler[_0x5e71f9(0x171)] = /^(check|device|dispositivo|checkb)$/i, handler['group'] = !![], handler[_0x5e71f9(0x18c)] = ![], handler['botAdmin'] = ![], handler[_0x5e71f9(0x1aa)] = null;
export default handler;